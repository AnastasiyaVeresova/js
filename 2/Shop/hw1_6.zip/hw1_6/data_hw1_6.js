const dataProducts = `[
    {
        "name": "ELLERY X M'O CAPSULE",
        "price": 52.00,
        "text": "Known for her sculptural takes on traditional tailoring, Australian arbiter of cool Kym Ellery teams up with Moda Operandi.",
        "url": "img/item1.jpg"
    },
        {
        "name": "ELLERY X M'O CAPSULE",
        "price": 52.00,
        "text": "Known for her sculptural takes on traditional tailoring, Australian arbiter of cool Kym Ellery teams up with Moda Operandi.",
        "url": "img/item2.png"
    },
        {
        "name": "ELLERY X M'O CAPSULE",
        "price": 52.00,
        "text": "Known for her sculptural takes on traditional tailoring, Australian arbiter of cool Kym Ellery teams up with Moda Operandi.",
        "url": "img/item3.png"
    },
        {
        "name": "ELLERY X M'O CAPSULE",
        "price": 52.00,
        "text": "Known for her sculptural takes on traditional tailoring, Australian arbiter of cool Kym Ellery teams up with Moda Operandi.",
        "url": "img/item4.png"
    },
        {
        "name": "ELLERY X M'O CAPSULE",
        "price": 52.00,
        "text": "Known for her sculptural takes on traditional tailoring, Australian arbiter of cool Kym Ellery teams up with Moda Operandi.",
        "url": "img/item5.png"
    },    
        {
        "name": "ELLERY X M'O CAPSULE",
        "price": 52.00,
        "text": "Known for her sculptural takes on traditional tailoring, Australian arbiter of cool Kym Ellery teams up with Moda Operandi.",
        "url": "img/item6.png"
    }
]`;

// Преобразование строки JSON в объект JavaScript
const data = JSON.parse(dataProducts);





